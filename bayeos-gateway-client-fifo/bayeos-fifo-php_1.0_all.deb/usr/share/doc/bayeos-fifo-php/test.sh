#!/bin/sh
count = 1
while(sleep 1)
do
  a=`date -u +%s`
  count=$(($count +1))
  echo "1 5 $count"
  if [ $count -eq 10 ]
  then
  echo "Test-Error" 1>&2
  count=1
  fi
done
